﻿namespace Library.Models.Book
{
    public class BookCategoryModel
    {
        public int Id { get; init; }

        public string Name { get; init; } = null!;
    }
}
